package com.example.tickets;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RequestMapping("/tickets")
@RestController
public class TicketsController {
    private List<Tickets> tickets = Arrays.asList(
            new Tickets(1, 201, 1001),
            new Tickets(2, 202 , 1002));
    
    @GetMapping
    public List<Tickets> getAllTickets() {
        return tickets;
    }
    
    @GetMapping("/{id}")
    public Tickets getTicketById(@PathVariable int id) {
        return tickets.stream()
                        .filter(customer -> customer.getId() == id)
                        .findFirst()
                        .orElseThrow(IllegalArgumentException::new);
    }
}