package com.example.tickets;
public class Tickets {
    private final int id;
    private final int ticket_id;
    private final int price;

    public Tickets(final int id,  final int ticket_id, final int price) {
        this.id = id;
        this.ticket_id = ticket_id;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public int getTicketId() {
        return ticket_id;
    }
    public int getPrice() {
        return price;
    }
}