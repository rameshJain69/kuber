package com.example.booking;
public class Booking {
    private final int id;
    private final int movie_id;
    private final String actor_name;

    public Booking(final int id,  final int movie_id, final String actor_name) {
        this.id = id;
        this.movie_id = movie_id;
        this.actor_name = actor_name;
    }

    public int getId() {
        return id;
    }

    public int getMovieId() {
        return movie_id;
    }

    public String getActorName() {
        return actor_name;
    }
    
}